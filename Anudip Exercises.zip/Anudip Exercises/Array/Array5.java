
import java.util.*;
public class Array5 {
   public static void main(String[] args) {
	   
	   int[] arr = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20};
for (int i = 0; i < arr.length; i++) {
	System.out.println("Element at index "+i+" :"+arr[i]);
}
   } 
}

/*
OUTPUT
Element at index 0 :1
Element at index 1 :2
Element at index 2 :3
Element at index 3 :4
Element at index 4 :5
Element at index 5 :6
Element at index 6 :7
Element at index 7 :8
Element at index 8 :9
Element at index 9 :10
Element at index 10 :11
Element at index 11 :12
Element at index 12 :13
Element at index 13 :14
Element at index 14 :15
Element at index 15 :16
Element at index 16 :17
Element at index 17 :18
Element at index 18 :19
Element at index 19 :20
*/
