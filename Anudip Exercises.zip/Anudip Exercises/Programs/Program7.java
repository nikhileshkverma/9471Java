class Program7 {
	public static void main(String args[])
	{
		byte b = 50;
		b =(byte)(b * 2);
		System.out.println(b);
	}
}
